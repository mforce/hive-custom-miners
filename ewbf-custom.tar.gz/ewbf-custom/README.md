# EWBF 0.4 custom hiveos miner

More info at https://bitcointalk.org/index.php?topic=4466962.0
